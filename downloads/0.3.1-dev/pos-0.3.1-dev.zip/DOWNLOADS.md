# Download POS

The complete package contains the matching USB installer, SD installation files,
USB helper scripts, checksums, feature status and full installation instructions.
You do not need to compile the OS to use a prebuilt package.

## Current development package

**POS 0.3.1-dev — experimental, hardware validation not yet performed.**

- [Download pos-0.3.1-dev.zip](https://github.com/thatsockmonke/POS/raw/refs/heads/main/downloads/0.3.1-dev/pos-0.3.1-dev.zip)
- [Download its SHA-256 checksum](https://github.com/thatsockmonke/POS/raw/refs/heads/main/downloads/0.3.1-dev/pos-0.3.1-dev.zip.sha256)
- [Browse versioned downloads](https://github.com/thatsockmonke/POS/tree/main/downloads)
- [Full installation guide](INSTALL.md)
- [Implemented / partial / planned features](STATUS.md)

These links point to files committed with the corresponding source revision. For
a private repository, sign into the GitHub account with access before downloading;
the repository does **not** need to be public. If publishing the current changes
has not succeeded, the links will not exist yet: use the generated workspace
artifacts or the build steps below. A cloud environment being published does not
by itself push source or create a GitHub firmware release.

Extract the named POS ZIP, **not GitHub's automatic Source code ZIP**, and follow
`INSTALL.md` inside it. Flash only `pos-installer-usb.bin` at 0x0; extract the inner
`pos-install.zip` onto FAT32 microSD. Do not flash its runtime binary manually at 0x0.

## GitHub Actions and Releases

The **Build and package POS** workflow builds both roles, runs host tests, then
exports the same complete installation bundle. After a successful run, open
**Actions → Build and package POS → the run → Artifacts → pos-firmware-VERSION**.
GitHub may wrap the artifact in another ZIP; extract that wrapper, then use the
named `pos-VERSION.zip` and `.sha256` file inside.

Pushing a matching `vVERSION` tag runs the checks and creates an **experimental
prerelease** with the ZIP/checksum attached. The tag must match `PROJECT_VER` in
CMakeLists.txt. The main branch build uploads artifacts; it does not automatically
claim hardware validation or mark development firmware stable.

## Build a package yourself

From the source checkout with ESP-IDF v5.5.5 activated:

```sh
python tools/posctl.py build
python -m unittest discover -s tests -v
python tools/posctl.py bundle --output dist/pos-0.3.1-dev --zip-output dist/pos-0.3.1-dev.zip
```

Choose a fresh output name if one already exists. `bundle` verifies images and
includes checksums; the outer ZIP adds a `.sha256` sidecar. The downloaded bundle's
USB helper scripts work with pip-installed esptool. Building firmware or running
native recovery helpers requires the **full source checkout** and SDK, not just
the two copied USB scripts in the binary download.
